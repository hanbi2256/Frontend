# Commit-Rule

# Commit-Rule

### **Commit Type**

[제목 없음](https://www.notion.so/811b4e3cca5c45119ac5e40a34d2ac1b)

`CommitType :: (#issue number) Subject`

모든 커밋은 위의 커밋 규칙을 지켜 작성한다.

Subject는 되도록이면 한글로 작성한다.

## 예시

```
🌱 :: 페이지 생성
🌧 :: 댓글 알림 Response 작성
```